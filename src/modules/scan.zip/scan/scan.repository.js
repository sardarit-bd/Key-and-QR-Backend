import ScanHistory from "./scan.model.js";

const createScan = (payload) => {
  return ScanHistory.create(payload);
};

const countTodayScans = (tagId, dateKey) => {
  return ScanHistory.countDocuments({
    tag: tagId,
    scanDateKey: dateKey,
  });
};

const countTodayScansByUser = (tagId, userId, dateKey) => {
  return ScanHistory.countDocuments({
    tag: tagId,
    user: userId,
    scanDateKey: dateKey,
  });
};

const getUsedQuoteIds = (tagId, dateKey) => {
  return ScanHistory.find({
    tag: tagId,
    scanDateKey: dateKey,
  }).distinct("quote");
};

const getUsedQuoteIdsByUser = (tagId, userId, dateKey) => {
  return ScanHistory.find({
    tag: tagId,
    user: userId,
    scanDateKey: dateKey,
  }).distinct("quote");
};

const getLastScan = async (tagId) => {
  return ScanHistory.findOne({ tag: tagId })
    .sort({ createdAt: -1 })
    .populate("quote", "text category");
};

const getTodayScan = async (tagId, dateKey) => {
  return ScanHistory.findOne({
    tag: tagId,
    scanDateKey: dateKey,
  }).populate("quote", "text category");
};

const getTodayScanByUser = async (tagId, userId, dateKey) => {
  return ScanHistory.findOne({
    tag: tagId,
    user: userId,
    scanDateKey: dateKey,
  }).populate("quote", "text category");
};

const getScanByTagAndDate = async (tagId, dateKey) => {
  return ScanHistory.findOne({
    tag: tagId,
    scanDateKey: dateKey,
  }).populate("quote", "text category");
};

const getUserScanHistory = async (userId, page = 1, limit = 10) => {
  const skip = (page - 1) * limit;

  const [data, total] = await Promise.all([
    ScanHistory.find({ user: userId })
      .populate("tag", "tagCode")
      .populate("quote", "text category")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit),
    ScanHistory.countDocuments({ user: userId }),
  ]);

  return {
    meta: {
      page: parseInt(page),
      limit: parseInt(limit),
      total,
      totalPage: Math.ceil(total / limit),
    },
    data,
  };
};

const getUserScanStats = async (userId) => {
  const scans = await ScanHistory.find({ user: userId }).sort({ createdAt: -1 });

  const todayKey = new Date().toISOString().split("T")[0];
  const todayScans = scans.filter((s) => s.scanDateKey === todayKey).length;

  const uniqueTags = new Set(scans.map((s) => s.tag?.toString())).size;

  const categoryCount = {};
  scans.forEach((scan) => {
    if (scan.category) {
      categoryCount[scan.category] = (categoryCount[scan.category] || 0) + 1;
    }
  });

  return {
    totalScans: scans.length,
    todayScans,
    uniqueTags,
    categoryDistribution: categoryCount,
    lastScan: scans[0] || null,
  };
};

/**
 * Get scan count for a user
 * Used for dashboard counts
 */
const getUserScanCount = async (userId) => {
  return ScanHistory.countDocuments({ user: userId });
};

export default {
  createScan,
  countTodayScans,
  countTodayScansByUser,
  getUsedQuoteIds,
  getUsedQuoteIdsByUser,
  getLastScan,
  getTodayScan,
  getTodayScanByUser,
  getScanByTagAndDate,
  getUserScanHistory,
  getUserScanStats,
  getUserScanCount,
};